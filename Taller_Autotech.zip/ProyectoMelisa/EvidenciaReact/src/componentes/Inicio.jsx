import React from 'react'
import logo from '../img/logo.png'

export const Inicio = () => {
  return (
    <>
         <div className="contenedor">
            <img src={logo} className="imagen-centrada"  />
        </div>
    </>
  )
}
